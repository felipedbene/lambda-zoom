import json
import os
import requests
import logging
import boto3
from botocore.exceptions import ClientError


def lambda_handler(event, context):
    
    #Zoom meta data from the webhook
    account_id = event["payload"]["account_id"]
    host_id = event["payload"]["object"]["host_id"]
    topic = event["payload"]["object"]["topic"].replace(" ","")
    name = "{}-{}-{}.mp4".format(account_id,host_id,topic)
    
    if "bucket" in os.environ :
        s3bucket = os.environ("bucket")
    else :
        s3bucket = "notasdofelip"
    
    for media in event["payload"]["object"]["recording_files"] :
        if "recording_type" in media :
            if media["recording_type"] == "shared_screen_with_speaker_view" :
                response = requests.get(media["download_url"])
                with open("/tmp/"+name, 'wb') as fd:
                    for chunk in response.iter_content(chunk_size=128):
                        fd.write(chunk)
                fd.close()
                upload_file("/tmp/"+name, s3bucket,name)

    
    return {
        'statusCode': 200,
        'body': json.dumps('{} uploaded to bucket {}'.format(name,s3bucket))
    }

def upload_file(file_name, bucket, object_name=None):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """

    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = file_name

    # Upload the file
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
    except ClientError as e:
        logging.error(e)
        return False
    return True